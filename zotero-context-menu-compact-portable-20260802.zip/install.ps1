$ErrorActionPreference = 'Stop'

$zoteroRoot = Join-Path $env:APPDATA 'Zotero\Zotero'
$profilesIni = Join-Path $zoteroRoot 'profiles.ini'
if (-not (Test-Path -LiteralPath $profilesIni)) {
    throw "Zotero profiles.ini was not found: $profilesIni"
}

$ini = Get-Content -LiteralPath $profilesIni -Encoding UTF8
$profiles = @()
$current = $null
foreach ($line in $ini) {
    if ($line -match '^\[Profile\d+\]$') {
        if ($current) { $profiles += [pscustomobject]$current }
        $current = @{}
        continue
    }
    if ($current -and $line -match '^([^=]+)=(.*)$') {
        $current[$Matches[1]] = $Matches[2]
    }
}
if ($current) { $profiles += [pscustomobject]$current }

$profile = $profiles | Where-Object { $_.Default -eq '1' } | Select-Object -First 1
if (-not $profile) { $profile = $profiles | Select-Object -First 1 }
if (-not $profile -or -not $profile.Path) { throw 'No Zotero profile was found.' }

$profilePath = if ($profile.IsRelative -eq '1') {
    Join-Path $zoteroRoot ($profile.Path -replace '/', '\')
} else {
    $profile.Path
}
if (-not (Test-Path -LiteralPath $profilePath)) {
    throw "Zotero profile directory was not found: $profilePath"
}

$running = Get-Process zotero -ErrorAction SilentlyContinue
if ($running) {
    throw 'Zotero is running. Close it completely before installing this fix.'
}

$chromeDir = Join-Path $profilePath 'chrome'
$targetCss = Join-Path $chromeDir 'userChrome.css'
$userJs = Join-Path $profilePath 'user.js'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$backupDir = Join-Path $profilePath "codex-menu-css-backup-$stamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
New-Item -ItemType Directory -Path $chromeDir -Force | Out-Null

if (Test-Path -LiteralPath $targetCss) {
    Copy-Item -LiteralPath $targetCss -Destination (Join-Path $backupDir 'userChrome.css')
}
if (Test-Path -LiteralPath $userJs) {
    Copy-Item -LiteralPath $userJs -Destination (Join-Path $backupDir 'user.js')
}

$block = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'userChrome.css') -Raw -Encoding UTF8
$existing = if (Test-Path -LiteralPath $targetCss) {
    Get-Content -LiteralPath $targetCss -Raw -Encoding UTF8
} else { '' }
$pattern = '(?s)/\* CODEX-ZOTERO-COMPACT-ITEM-MENU:BEGIN \*/.*?/\* CODEX-ZOTERO-COMPACT-ITEM-MENU:END \*/'
$nextCss = if ($existing -match $pattern) {
    [regex]::Replace($existing, $pattern, $block.Trim())
} else {
    ($existing.TrimEnd() + "`r`n`r`n" + $block.Trim() + "`r`n").TrimStart()
}
[IO.File]::WriteAllText($targetCss, $nextCss, [Text.UTF8Encoding]::new($false))

$prefLine = 'user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);'
$userText = if (Test-Path -LiteralPath $userJs) {
    Get-Content -LiteralPath $userJs -Raw -Encoding UTF8
} else { '' }
$prefPattern = '(?m)^user_pref\("toolkit\.legacyUserProfileCustomizations\.stylesheets",\s*(?:true|false)\);\s*$'
$nextUser = if ($userText -match $prefPattern) {
    [regex]::Replace($userText, $prefPattern, $prefLine)
} else {
    $userText.TrimEnd() + "`r`n" + $prefLine + "`r`n"
}
[IO.File]::WriteAllText($userJs, $nextUser, [Text.UTF8Encoding]::new($false))

Write-Host "Installed into: $profilePath"
Write-Host "Backup created at: $backupDir"
Write-Host 'Start Zotero and test the item context menu.'
