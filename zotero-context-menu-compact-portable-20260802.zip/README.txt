Zotero item context-menu compact fix
====================================

Target: Zotero 9 on Windows. The CSS is version-specific UI customization;
recheck selectors before using it with a future major Zotero release.

Purpose
-------
Makes the main library right-click menu shorter so lower entries remain
reachable. It is static CSS and does not run background JavaScript.

Recommended installation on Windows
-----------------------------------
1. Close Zotero completely.
2. Right-click install.ps1 and choose Run with PowerShell, or run:
   powershell -ExecutionPolicy Bypass -File .\install.ps1
3. Start Zotero and test the item right-click menu.

Manual installation
-------------------
1. Open Zotero's active profile folder, not the Zotero program/install folder.
2. Create a chrome folder if it does not exist.
3. Merge the marked block from userChrome.css into chrome\userChrome.css.
4. In about:config set:
   toolkit.legacyUserProfileCustomizations.stylesheets = true
5. Restart Zotero.

The installer backs up existing files and only manages the block between the
CODEX-ZOTERO-COMPACT-ITEM-MENU markers. It does not copy personal data.
